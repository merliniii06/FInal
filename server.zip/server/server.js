// Import required modules
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

// Create an instance of Express
const app = express();
const PORT = 3000;

app.use(cors());

// Middleware to parse JSON
app.use(express.json());

// Database connection configuration
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'final'
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        process.exit(1);
    }
    console.log('Connected to the database.');
});

// Define a route to fetch all data from a table
app.get('/api/data', (req, res) => {
    const query = 'SELECT * FROM course';

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            return res.status(500).json({ error: 'Database query failed' });
        }

        res.json(results);
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
