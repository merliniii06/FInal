<?php
session_start();
include('config.php');

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id']; // Get the user_id from the session

// Fetch current user details from the database
$sql = "SELECT u.username, u.email, u.contact
        FROM users u
        WHERE u.id = ?";  // Make sure 'id' is the correct column name in your table
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user_id parameter
$stmt->execute();
$result = $stmt->get_result();
$userProfile = $result->fetch_assoc(); // Fetch user profile data

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get updated settings from the form
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Ensure passwords match
    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
        exit;
    }

    // Hash the password before saving (only if password is updated)
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    } else {
        $hashed_password = $userProfile['password']; // Keep the old password if not updated
    }

    // Update the users table with new data (username, email, contact, password)
    $sql = "UPDATE users SET email = ?, contact = ?, username = ?, password = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $email, $contact, $username, $hashed_password, $user_id);

    if ($stmt->execute()) {
        // Update session variables with new values to reflect changes immediately
        $_SESSION['email'] = $email;
        $_SESSION['contact'] = $contact;
        $_SESSION['username'] = $username;

        echo "Settings updated successfully!";
    } else {
        echo "Error updating settings: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Management Dashboard</title>
    <link rel="stylesheet" href="settings.css">
</head>

<body>
    <div class="container">
        <!-- Header Section -->
        <header>
            <h2>Course Enrollment Dashboard</h2>
        </header>

        <!-- Dashboard Layout -->
        <!-- Sidebar -->
        <div class="sidebar">
            <img src="logo.png" alt="Logo" class="sidebar-logo">
            <div class="sidebar-section">
                <br><br>    
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="enrollment.php">Courses</a></li>
                    <li><a href="payment.php">Balance/Tuition</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="signup.php" class="logout-btn">Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Main Dashboard Section -->
        <div class="main-dashboard">
            <!-- Settings Container -->
            <div class="settings-container">
                <h3>Update Account Information</h3>

                <!-- Settings Form -->
                <form id="settings-form" method="POST" action="settings.php">
                    <div class="form-group">
                        <label for="username">Full Name</label>
                        <input type="text" id="username" name="username" placeholder="Enter your new username" value="<?= htmlspecialchars($userProfile['username']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Enter your new email" value="<?= htmlspecialchars($userProfile['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="contact">Contact Number</label>
                        <input type="text" id="contact" name="contact" placeholder="Enter your new contact number" value="<?= htmlspecialchars($userProfile['contact']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your new password">
                    </div>
                    <div class="form-group">
                        <label for="confirm-password">Confirm Password</label>
                        <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm your password">
                    </div>
                    <button type="submit" class="submit-btn">Update Information</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
