<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('config.php'); // Include the database connection

// Start session to track user login
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Simple validation
    if (empty($email) || empty($password)) {
        echo "Email and password are required!";
    } else {
        // Query to check if the email exists
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // User exists, now check the password
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Password matches, store user data in session
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                
            if($row['is_verified'] == 1){
                header("Location: dashboard.php");
            }

            else{
                header("Location: verification.php"); 
                exit(); // Stop further script execution
            }
            } else {
                echo "Invalid password!";
            }
        } else {
            echo "No user found with that email!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>

<body>
    <div class="container">
        <div class="content">
            <div class="left">
                <form action="login.php" method="POST">
                    <div class="h2login">
                        <h2>LOGIN</h2>
                    </div>
                    <p>Enter Your Account Details</p>

                    <div class="login">
                        <input type="email" name="email" placeholder="Email" required>
                        <input type="password" name="password" placeholder="Password" required>
                    </div>

                    <button class="loginbutton">Login</button>

                    <div class="signups">
                        <p>Don't have an account?</p>
                        <a href="signup.php" class="signup_btn">Sign up</a>
                    </div>
                </form>
            </div>

            <div class="right">
                <div class="join_us">
                </div>
                <div class="image-container">
                    <img src="login.jfif" alt="image">
                </div>
            </div>
        </div>
    </div>
</body>

</html>
