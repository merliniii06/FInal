<?php
// Start session to manage user login
session_start();

// Include database connection file
include_once 'config.php';  // Make sure to create a database connection script (db_connection.php)

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit();
}

// Function to get enrolled courses for the logged-in user
function getEnrolledCourses($user_id) {
    global $conn;  // Assuming $conn is your database connection
    $sql = "SELECT * FROM courses WHERE user_id = ?"; // Query the courses table
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $courses = [];
    while ($row = $result->fetch_assoc()) {
        $courses[] = $row;
    }
    return $courses;
}

// Function to check if a student has completed a prerequisite for a specific semester
function hasCompletedSemesterPrerequisites($user_id, $semester) {
    global $conn;

    // Define the required courses for each semester
    $semester_courses = [
        '1st Year - Semester 1' => [],
        '1st Year - Semester 2' => ['Data Structures', 'Discrete Mathematics', 'Operating Systems'],
        '2nd Year - Semester 1' => ['Algorithms', 'Database Systems', 'Web Development'],
        '2nd Year - Semester 2' => ['Software Engineering', 'Computer Networks', 'Computer Graphics'],
        '3rd Year - Semester 1' => ['Artificial Intelligence', 'Theory of Computation', 'Data Communication'],
        '3rd Year - Semester 2' => ['Machine Learning', 'Computer Vision', 'Mobile Development'],
        '4th Year - Semester 1' => ['Big Data', 'Cloud Computing', 'Capstone Project'],
        '4th Year - Semester 2' => ['Internship', 'Advanced Software Engineering', 'Capstone Project'],
    ];

    // Get the courses the user has completed in previous semesters
    $completed_courses = getEnrolledCourses($user_id);
    $completed_courses_names = array_map(function($course) { return $course['course_name']; }, $completed_courses);

    // Check if the user has completed all prerequisites for the specified semester
    $required_courses = $semester_courses[$semester];
    foreach ($required_courses as $course) {
        if (!in_array($course, $completed_courses_names)) {
            return false;  // User has not completed one of the required courses
        }
    }

    return true;  // User has completed all prerequisites
}

// Handle enrolling in a course
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['enroll_course'])) {
    $course_name = $_POST['course_name'];
    $schedule = $_POST['schedule'];  // You can add more fields depending on your table structure
    $user_id = $_SESSION['user_id'];

    // Determine the semester for the course being enrolled in
    $semester = $_POST['semester'];  // The semester value can be passed via a hidden input

    // Check if the user has completed the prerequisites for the semester
    if (hasCompletedSemesterPrerequisites($user_id, $semester)) {
        // Insert the course into the database if prerequisites are met
        $sql = "INSERT INTO courses (user_id, course_name, schedule, paid) VALUES (?, ?, ?, 0)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $user_id, $course_name, $schedule);
        $stmt->execute();

        // Redirect back to the enrollment page after enrolling
        header('Location: enrollment.php');
        exit();
    } else {
        // Show an error message if prerequisites are not met
        echo "<script>alert('You must complete the prerequisite courses before enrolling in this course.');</script>";
    }
}

// Handle dropping a course
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['drop_course'])) {
    $course_id = $_POST['course_id'];

    // Delete the course from the database
    $sql = "DELETE FROM courses WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $course_id);
    $stmt->execute();

    // Redirect back to the enrollment page after dropping the course
    header('Location: enrollment.php');
    exit();
}

$user_id = $_SESSION['user_id']; // Get the user_id from session
$courses = getEnrolledCourses($user_id);  // Get the enrolled courses for the logged-in user
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment</title>
    <link rel="stylesheet" href="enrollment.css">
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-section">
            <img src="logo.png" alt="Logo" class="sidebar-logo">
            <br><br>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="enrollment.php">Courses</a></li>
                <li><a href="payment.php">Balance/Tuition</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="signup.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="container">
        <header>
            <h2>Enrollment</h2>
        </header>

        <div class="dashboard">
            <div class="main-dashboard">
                <div class="nav-tabs">
                    <a href="#" onclick="showTab('enroll')" class="active">Enroll</a>
                    <a href="#" onclick="showTab('drop')">Drop</a>
                    <a href="#" onclick="showTab('schedule')">Schedule</a>
                </div>

                <!-- Enroll Section -->
                    <div id="enroll" class="year-courses">
                       
                    </div> <!-- End of Enroll Section -->

                <!-- Drop Section -->
                <div id="drop" class="year-courses" style="display:none;">
                    <h3>Courses You Are Enrolled In</h3>
                    <table class="course-table">
                        <thead>
                            <tr>
                                <th>Course</th>
                                <th>Schedule</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($courses as $course): ?>
                                <tr>
                                    <td><?= $course['course_name'] ?></td>
                                    <td><?= $course['schedule'] ?></td>
                                    <td>
                                        <form method="POST" action="enrollment.php">
                                            <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                                            <button type="submit" name="drop_course" class="drop-btn">Drop</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Schedule Section -->
                <div id="schedule" class="year-courses" style="display:none;">
                    <h3>Your Schedule</h3>
                    <table class="course-table">
                        <thead>
                            <tr>
                                <th>Course</th>
                                <th>Schedule</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($courses as $course): ?>
                                <tr>
                                    <td><?= $course['course_name'] ?></td>
                                    <td><?= $course['schedule'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <script>

document.addEventListener("DOMContentLoaded", () => {
    console.log('Script Loaded');
    const apiUrl = "http://localhost:3000/api/data";
    const container = document.getElementById("enroll");

    if (!container) {
        console.error("Container with ID 'enroll' not found!");
        return;
    }

    console.log('Fetching data from API...');
    fetch(apiUrl)
        .then(response => {
            console.log('Response received');
            if (!response.ok) {
                console.error("Network response was not ok: " + response.statusText);
                throw new Error("Network response was not ok " + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log('Data fetched:', data);

            // Group courses by year and semester
            const groupedData = {};
            data.forEach(course => {
                const [year, semester] = course.semester.split(" - ");
                if (!groupedData[year]) groupedData[year] = {};
                if (!groupedData[year][semester]) groupedData[year][semester] = [];
                groupedData[year][semester].push(course);
            });

            console.log('Grouped Data:', groupedData);

            // Append grouped data to the DOM
            for (const year in groupedData) {
                for (const semester in groupedData[year]) {
                    console.log(`Appending ${year} - ${semester}`);

                    const yearSection = document.createElement("div");
                    yearSection.classList.add("year-section");

                    // Add year and semester heading
                    const yearHeading = document.createElement("h3");
                    yearHeading.textContent = `${year} - ${semester}`;
                    yearSection.appendChild(yearHeading);

                    // Create table
                    const table = document.createElement("table");
                    table.classList.add("course-table");

                    // Table headers
                    const thead = document.createElement("thead");
                    thead.innerHTML = `
                        <tr>
                            <th>Course</th>
                            <th>Schedule</th>
                            <th>Action</th>
                        </tr>
                    `;
                    table.appendChild(thead);

                    // Table body
                    const tbody = document.createElement("tbody");
                    groupedData[year][semester].forEach(course => {
                        const row = document.createElement("tr");

                        // Course name
                        const courseCell = document.createElement("td");
                        courseCell.textContent = course.course_name;
                        row.appendChild(courseCell);

                        // Schedule
                        const scheduleCell = document.createElement("td");
                        scheduleCell.textContent = course.schedule;
                        row.appendChild(scheduleCell);

                        // Enroll button
                        const actionCell = document.createElement("td");
                        const form = document.createElement("form");
                        form.method = "POST";
                        form.action = "enrollment.php";

                        // Hidden inputs
                        form.innerHTML = `
                            <input type="hidden" name="course_name" value="${course.course_name}">
                            <input type="hidden" name="schedule" value="${course.schedule}">
                            <input type="hidden" name="semester" value="${course.semester}">
                        `;

                        const button = document.createElement("button");
                        button.type = "submit";
                        button.name = "enroll_course";
                        button.classList.add("enroll-btn");
                        button.textContent = "Enroll";
                        form.appendChild(button);

                        actionCell.appendChild(form);
                        row.appendChild(actionCell);

                        tbody.appendChild(row);
                    });

                    table.appendChild(tbody);
                    yearSection.appendChild(table);
                    container.appendChild(yearSection);
                }
            }
            console.log('Appending completed');
        })
        .catch(error => console.error("Error fetching data:", error));
});



        function showTab(tab) {
            // Hide all sections
            document.getElementById('enroll').style.display = 'none';
            document.getElementById('drop').style.display = 'none';
            document.getElementById('schedule').style.display = 'none';

            // Show the selected tab
            document.getElementById(tab).style.display = 'block';

            // Update active tab
            var tabs = document.querySelectorAll('.nav-tabs a');
            tabs.forEach(function(tab) {
                tab.classList.remove('active');
            });
            document.querySelector(`[onclick="showTab('${tab}')"]`).classList.add('active');
        }
    </script>

</body>
</html>
