<?php
// Include the database connection
include('config.php'); 
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; // Get the logged-in user's ID

    // Prepare SQL query to fetch user data (without profile_image)
    $sql = "SELECT id, username, email FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id); // Bind the user_id to the prepared statement
    $stmt->execute(); // Execute the query
    $result = $stmt->get_result(); // Get the result of the query

    // Fetch user data if found
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc(); // Get user data as an associative array
    } else {
        // User not found in the database
        echo "User not found.";
        exit;
    }

    // Fetch courses for the logged-in user
    $course_sql = "SELECT id, course_name, schedule, paid FROM courses WHERE user_id = ?";
    $course_stmt = $conn->prepare($course_sql);
    $course_stmt->bind_param("i", $user_id); // Bind the user_id to the prepared statement
    $course_stmt->execute(); // Execute the query
    $course_result = $course_stmt->get_result(); // Get the result of the query

    // Store enrolled courses in an array
    $enrolledCourses = [];
    $unpaidCourses = 0;
    $totalUnits=0;
    $totalPayment = 0; // Initialize total payment

    if ($course_result->num_rows > 0) {
        while ($course_row = $course_result->fetch_assoc()) {
            $enrolledCourses[] = $course_row['course_name'] . " - " . $course_row['schedule'];
            // If the course is unpaid, count it and add 1000 to the total payment
            $sql = "SELECT COUNT(*) as total_courses FROM courses WHERE user_id = '$user_id' && paid = 0";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                $row = mysqli_fetch_assoc($result);
                $totalUnits =  $row['total_courses'];
                $totalPayment = $row['total_courses'] * 1000;
            }
        }
    } else {
        // Only add this message if there are truly no courses enrolled
        $enrolledCourses[] = "No courses enrolled yet.";
    }

    // Placeholder variables for payment summary

} else {
    echo "Please log in to access this page.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment</title>
    <link rel="stylesheet" href="dashboard.css">
</head>

<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-section">
                <img src="logo.png" alt="Logo" class="sidebar-logo">
                <br><br>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="enrollment.php">Courses</a></li>
                    <li><a href="payment.php">Balance/Tuition</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="signup.php" class="logout-btn">Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container">
            <!-- Dashboard Header -->
            <div class="dashboard-header">
                <h1>Welcome, <?php echo htmlspecialchars($user['username']); ?></h1>
                <p>Your current enrollment and payment summary.</p>
            </div>

            <!-- Enrollment Summary Section -->
            <div class="enrollment-summary">
                <h3>Enrolled Courses</h3>
                <ul id="course-list">
                    <?php if (count($enrolledCourses) > 0): ?>
                        <?php foreach ($enrolledCourses as $course): ?>
                            <li><?php echo htmlspecialchars($course); ?></li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li>No courses enrolled yet.</li>
                    <?php endif; ?>
                </ul>
                <button onclick="window.location.href='enrollment.php'">Enroll in More Courses</button>
            </div>

            <!-- Payment Summary Section -->
            <div class="payment-summary">
                <h3>Payment Summary</h3>
                <p>Total Units: <span id="total-units"><?php echo $totalUnits; ?></span></p>
                <p>Total Payment Due: Php <span id="total-payment"><?php echo number_format($totalPayment, 2); ?></span></p>
                <a href="payment.php">Make Payment</a>
            </div>

            <hr>
            <br><br>

            <!-- About Massachusetts Section -->
            <div id="background" class="background">
                <center><img src="https://th.bing.com/th/id/OIP.cbFL7dOly4bxpLU1MqIAsAHaE4?rs=1&pid=ImgDetMain" alt="Massachusetts Image"></center>
            </div>
            <h3>About Massachusetts</h3>
            <p>Massachusetts is a state located in the northeastern United States. Known for its rich history...</p>
        </div>
    </div>
</body>

</html>
