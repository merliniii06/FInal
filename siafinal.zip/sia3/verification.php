<?php
session_start();
include('config.php'); // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the user ID from session
$user_id = $_SESSION['user_id'];

// Check if the verification code was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect the verification code inputs
    $code1 = $_POST['code1'];
    $code2 = $_POST['code2'];
    $code3 = $_POST['code3'];
    $code4 = $_POST['code4'];

    // Combine the input values into a full verification code
    $entered_code = $code1 . $code2 . $code3 . $code4;

    // Check if the entered code is correct (this example uses '1234' as the code)
    // In a real-world scenario, you'd compare with a code stored in the database or sent via email
    $correct_code = $_SESSION['otp'];  // For demo purposes; replace with actual logic
    echo $correct_code;
    if ($entered_code == $correct_code) {
        // Update the user's verification status in the database
        $sql = "UPDATE users SET is_verified = 1 WHERE id = $user_id";
        if ($conn->query($sql) === TRUE) {
            // Redirect the user to the dashboard after successful verification
            header("Location: dashboard.php"); // Redirect to the dashboard
            exit();
        } else {
            echo "Error updating verification status: " . $conn->error;
        }
    } else {
        echo "Invalid verification code!";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification Code</title>
    <link rel="stylesheet" href="verification.css">
</head>

<body>
    <div class="container">
        <div class="content">
            <div class="left">
                <form action="verification.php" method="POST">
                    <h2>Verification</h2>
                    <p class="h2login">Enter the code sent to your email</p>
                    <div class="verification-inputs">
                        <input type="text" name="code1" maxlength="1" required>
                        <input type="text" name="code2" maxlength="1" required>
                        <input type="text" name="code3" maxlength="1" required>
                        <input type="text" name="code4" maxlength="1" required>
                    </div>
                    <button type="submit">Verify Code</button>
                    
                </form>
            </div>

            <div class="right">
                <div class="join_us">
                    <h2>Verify your account now!</h2>
                </div>
                <div class="image-container">
                    <img src="OIP.jpg" alt="Image">
                </div>
            </div>
        </div>
    </div>
</body>

</html>
