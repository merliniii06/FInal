<?php
// Start session to get logged-in user's data
session_start();

// Assuming your database connection is already established
require_once('config.php');

// Variables to hold payment details
$total_units = 0;
$total_payment = 0.00;
$user_balance = 0.00;
$total_units1 = 0;

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Check if balance is in the session
    if (isset($_SESSION['user_balance'])) {
        // Use the balance stored in the session
        $sql_balance = "SELECT balance FROM users WHERE id = '$user_id'";
        $result_balance = mysqli_query($conn, $sql_balance);
        if ($result_balance) {
            $row = $result_balance->fetch_assoc();
            $user_balance = $row['balance'];
        } 
    } else {
        // Fetch the balance from the database if not found in the session
        
    }

    // Fetch total units and total payment (only for unpaid courses)
    $sql = "SELECT COUNT(*) as total_courses FROM courses WHERE user_id = '$user_id' && paid = 0";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $total_units = $row['total_courses'];
        $total_payment = $total_units * 1000;
    }

    $sql = "SELECT COUNT(*) as total_courses FROM courses WHERE user_id = '$user_id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $total_units1 = $row['total_courses'];
        $total_payment = $total_units * 1000;
    }
}

// Handle payment form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve payment amount from the form
    $payment_amount = $_POST['payment_amount'];

    // Check if the payment is valid
    if ($payment_amount > 0 && $payment_amount <= $total_payment) {
        // Perform the payment update logic (without affecting the user's balance)
        // Here we assume you want to track the payment in a new "payments" table, and update the user's balance

        // Insert payment record into the "payments" table
        $sql = "INSERT INTO payments (user_id, amount, payment_date) 
                VALUES ('$user_id', '$payment_amount', NOW())";  // Log the payment to a new table

        if (mysqli_query($conn, $sql)) {
            // Update user's balance after payment
            $sql_balance = "UPDATE users SET balance = balance - $payment_amount WHERE id = '$user_id'";  // Update balance
            if (mysqli_query($conn, $sql_balance)) {
                // Update the paid status for courses
                // Here we mark the courses as paid where the total payment amount is covered
                $sql_update_courses = "UPDATE courses 
                                       SET paid = 1 
                                       WHERE user_id = '$user_id' AND paid = 0";

                if (mysqli_query($conn, $sql_update_courses)) {
                    $payment_status = 'Payment submitted successfully!';
                    // Update session with new balance
                    $_SESSION['user_balance'] = $user_balance - $payment_amount;  // Update session with new balance
                    $user_balance -= $payment_amount;
                    $total_payment -= $payment_amount; // Adjust total payment
                } else {
                    $payment_status = 'Failed to update course payment status. Please try again.';
                }
            } else {
                $payment_status = 'Failed to update balance. Please try again.';
            }
        } else {
            $payment_status = 'Payment failed. Please try again.';
        }
    } else {
        $payment_status = 'Invalid payment amount.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment</title>
    <link rel="stylesheet" href="payment1.css">
    <style>
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999; /* Ensure the modal is on top */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
            padding-top: 50px;
            padding-right:20px;
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            width: 50%;
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            float: right;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

    </style>
</head>
<body>

    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-section">
                <img src="logo.png" alt="Logo" class="sidebar-logo">
                <br><br>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="enrollment.php">Courses</a></li>
                    <li><a href="payment.php">Balance/Tuition</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="signup.php" class="logout-btn">Logout</a></li>
                </ul>
            </div>
        </div>

        <!-- Payment Summary Section -->
        <div id="payment-summary">
            <h3>Payment Summary</h3>
            <p>Total Units: <span id="total-units"><?= $total_units1 ?></span></p>
            <p>Total Payment: Php <span id="total-payment"><?= number_format($total_payment, 2) ?></span></p>
            <p>Balance: Php <span id="total-balance"><?= number_format($user_balance, 2) ?></span></p>
            <button onclick="openModal()">Make Payment</button>
        </div>

        <!-- Payment Modal (Hidden by default) -->
        <div id="payment-modal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h3>Make Payment</h3>
                <p>Total Payment Due: Php <span id="modal-total-payment"><?= number_format($total_payment, 2) ?></span></p>
                <form id="payment-form" method="POST" action="payment.php">
                    <input type="number" id="payment-amount" name="payment_amount" placeholder="Enter payment amount" required />
                    <button type="submit">Submit Payment</button>
                    <button type="button" onclick="closeModal()">Cancel</button>
                </form>
            </div>
        </div>

        <!-- Display Payment Status -->
        <?php if (isset($payment_status)): ?>
            <div id="payment-status">
                <p><?= $payment_status ?></p>
            </div>
        <?php endif; ?>

    </div>

    <script src="payment.js"></script>

    <script>
        // Open the Payment Modal
        function openModal() {
            document.getElementById('payment-modal').style.display = 'block';
        }

        // Close the Payment Modal
        function closeModal() {
            document.getElementById('payment-modal').style.display = 'none';
        }
    </script>

</body>
</html>
