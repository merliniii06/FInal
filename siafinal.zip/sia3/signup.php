<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('config.php'); // Include the database connection


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Start session to track user
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $username = $_POST['username'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Simple validation
    if (empty($username) || empty($contact) || empty($email) || empty($password)) {
        echo "All fields are required!";
    } else {
        // Check if email already exists
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "Email already exists!";
        } else {
            // Insert new user into the database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (username, contact, email, password,is_verified) VALUES ('$username', '$contact', '$email', '$hashed_password',0)";

            if ($conn->query($sql) === TRUE) {
                $otp=rand(1000,9999);
                $_SESSION['otp'] = $otp;
                // Redirect to login page after successful signup
                try {
                    $mail = new PHPMailer(true);

                    // SMTP configuration
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'petresq4904@gmail.com'; // Use your Gmail address
                    $mail->Password = 'heox htft eweh tytv'; // App-specific password
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    // Sender and recipient
                    $mail->setFrom('petresq4904@gmail.com', 'petresq4904@gmail.com'); // Replace with your sender email and name
                    $mail->addAddress($email);

                    // Email content
                    $mail->isHTML(true);
                    $mail->Subject = "Email Verification";
                    $mail->Body = "Your OTP is: " . $otp;

                    // Send email
                    $mail->send();
                    echo 'OTP sent successfully. Check your email.';
                } catch (Exception $e) {
                    echo "Email sending failed. Error: " . $mail->ErrorInfo;
                }



                header("Location: login.php");
                exit();
            } else {
                echo "Error: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
    <div class="container">
        <div class="content">
            <div class="left">
                <form action="signup.php" method="POST">
                    <h2>Sign Up</h2>
                    <p>Create Your Account</p>
                    <div class="sign_up">
                        <input type="text" name="username" placeholder="Full Name" required>
                        <input type="text" name="contact" placeholder="Contact no." required>
                        <input type="text" name="email" placeholder="Email" required>
                        <input type="password" name="password" placeholder="Password" required>
                    </div>

                    <button class="sign_btn">Sign Up</button>

                    <p class="login-container">
                        Already Have an Account? 
                        <a href="login.php" class="log_btn">Log in</a>
                    </p>
                </form>
            </div>

            <div class="right">
                <div class="join_us">
                    <h2>Join us now and enroll!</h2>
                </div>
                <div class="image-container">
                    <img src="signup.jfif" alt="image">
                </div>
            </div>
        </div>
    </div>
</body>
</html>
