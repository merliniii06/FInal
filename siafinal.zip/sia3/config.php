<?php
// Database configuration
$servername = "localhost"; // Typically 'localhost' for local development
$username = "root";        // Your database username (default is 'root' for MySQL)
$password = "";            // Your database password (leave empty for default setup)
$dbname = "final";         // Name of the database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
