$(document).ready(function () {
    // Open modal when "Make Payment" button is clicked
    $('#make-payment-btn').on('click', function () {
        $('#payment-modal').show();  // Show the modal
    });

    // Close modal when "x" is clicked
    $('#close-modal').on('click', function () {
        $('#payment-modal').hide();  // Hide the modal
    });

    // Close modal when "Cancel" button is clicked
    $('#cancel-payment-btn').on('click', function () {
        $('#payment-modal').hide();  // Hide the modal
    });

    // Handle form submission with AJAX
    $('#payment-form').submit(function (e) {
        e.preventDefault(); // Prevent the form from submitting normally

        var paymentAmount = $('#payment-amount').val();  // Get the payment amount
        var totalPayment = $('#modal-total-payment').text();  // Total payment due (from modal)

        if (parseFloat(paymentAmount) > parseFloat(totalPayment)) {
            alert("Payment amount cannot exceed the total amount due.");
            return;
        }

        // Perform the AJAX request to process the payment
        $.ajax({
            type: 'POST',
            url: 'payment.php',
            data: {
                payment_amount: paymentAmount
            },
            dataType: 'json',
            success: function (response) {
                if (response.status == 'success') {
                    // Update the balance on the dashboard
                    $('#total-balance').text(response.new_balance);  // Update balance on the dashboard
                    $('#payment-summary').html("<p>Payment successful. New balance: Php " + response.new_balance + "</p>");

                    // Close the modal after successful payment
                    $('#payment-modal').hide();
                } else {
                    alert(response.message);  // Show error message if any
                }
            },
            error: function () {
                alert('Error processing payment. Please try again.');
            }
        });
    });
});
