<?php
session_start();
include('database_connection.php');  // Ensure you have a proper database connection

if (isset($_POST['course_name']) && isset($_POST['course_time'])) {
    $course_name = $_POST['course_name'];
    $course_time = $_POST['course_time'];  // Assuming course time is part of the enrollment form

    $user_id = $_SESSION['user_id'];  // Assuming the user is logged in

    // Enroll the user in the course (example query)
    $query = "INSERT INTO user_courses (user_id, course_name, course_time) 
              VALUES ('$user_id', '$course_name', '$course_time')";
    
    if (mysqli_query($conn, $query)) {
        header('Location: enrollment.php'); // Redirect back to the enrollment page after successful enrollment
    } else {
        echo "Error: " . mysqli_error($conn); // Error handling
    }
} else {
    echo "Missing course information.";
}
?>
