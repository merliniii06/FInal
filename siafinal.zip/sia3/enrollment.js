let enrolledCourses = {}; // Object to store courses and their schedule
let schedule = {}; // Object to store the weekly schedule
let completedYears = [0]; // Array to track completed years (0 means no years completed yet)
let totalPayment = 0; // Track total payment for tuition
let isPaid = false; // Track payment status

// Course costs (Same as before)
let courseCosts = {
    'Mathematics 101': 800,
    'Computer Science Basics': 900,
    'Data Structures': 950,
    'Discrete Mathematics': 800,
    'Computer Architecture': 900,
    'Algorithms': 1100,
    'Operating Systems': 1000,
    'Computer Networks': 950,
    'Database Management': 1050,
    'Software Engineering': 1200,
    'Artificial Intelligence': 1500,
    'Cloud Computing': 1400,
    'Database Systems': 1200,
    'Web Development': 1300,
    'Machine Learning': 1600,
    'Mobile App Development': 1400,
    'Computer Graphics': 1200,
    'Blockchain Technology': 1800,
    'Big Data Analytics': 1700,
    'Cyber Security': 1500,
    'Cloud Architecture': 1600,
    'Advanced Machine Learning': 2000,
    'Internet of Things (IoT)': 1500
};

// Prerequisites for each course
let coursePrerequisites = {
    'Data Structures': ['Computer Science Basics'],
    'Algorithms': ['Data Structures'],
    'Operating Systems': ['Computer Architecture'],
    'Software Engineering': ['Data Structures'],
    'Artificial Intelligence': ['Algorithms'],
    'Cloud Computing': ['Operating Systems'],
    'Machine Learning': ['Algorithms'],
    'Web Development': ['Computer Science Basics'],
    'Cyber Security': ['Computer Networks'],
    'Blockchain Technology': ['Algorithms'],
    'Big Data Analytics': ['Machine Learning'],
    'Cloud Architecture': ['Cloud Computing'],
    'Advanced Machine Learning': ['Machine Learning'],
    'Mobile App Development': ['Web Development'],
    'Internet of Things (IoT)': ['Computer Networks']
};

// Show different sections (enroll, drop, schedule)
function showTab(tabName) {
    document.getElementById("enroll").style.display = "none";
    document.getElementById("drop").style.display = "none";
    document.getElementById("schedule").style.display = "none";
    
    document.getElementById(tabName).style.display = "block";
}

// Update the schedule table with enrolled courses
function updateScheduleTable(courses) {
    let scheduleTable = document.getElementById("schedule-table");
// Update the schedule table with enrolled courses
function updateScheduleTable(courses) {
    let scheduleTable = document.getElementById("schedule-table");

    // Clear existing schedule
    const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
    days.forEach(day => {
        let cell = document.getElementById(day);
        if (cell) cell.innerHTML = '';  // Clear previous data
    });

    // Add newly enrolled courses to the schedule table
    courses.forEach(course => {
        // Extract the schedule and assign it to the right day
        let schedule = course.schedule;  // Format: "Monday 9:00 AM - 12:00 PM"
        
        // Determine which day the course belongs to
        let dayOfWeek = schedule.split(" ")[0].toLowerCase();  // "Monday", "Tuesday", etc.

        // Check if the day exists in the table (monday, tuesday, etc.)
        if (days.includes(dayOfWeek)) {
            let cell = document.getElementById(dayOfWeek);
            if (cell) {
                cell.innerHTML += `<p>${course.course_name} (${course.schedule})</p>`;
            }
        }
    });
}

// Show different sections (enroll, drop, schedule)
function showTab(tabName) {
    document.getElementById("enroll").style.display = "none";
    document.getElementById("drop").style.display = "none";
    document.getElementById("schedule").style.display = "none";
    
    document.getElementById(tabName).style.display = "block";
}

    // Clear existing schedule
    for (let day in schedule) {
        let cell = document.getElementById(day);
        if (cell) cell.innerHTML = schedule[day];
    }

    // Add newly enrolled courses to the schedule table
    courses.forEach(course => {
        // You can modify the logic below to assign courses to specific days/times
        // For now, it's simply adding all courses to the "Monday" cell as an example
        let day = 'monday'; // Example, you need to modify this to assign properly
        let cell = document.getElementById(day);
        if (cell) {
            cell.innerHTML += `<p>${course.course_name} (${course.schedule})</p>`;
        }
    });
}
