<?php
session_start();
require_once('config.php');  // Database connection

// Check if the necessary POST data is set
if (isset($_POST['payment_amount']) && isset($_POST['user_id']) && isset($_POST['total_payment'])) {
    $payment_amount = $_POST['payment_amount'];  // Amount paid
    $user_id = $_POST['user_id'];  // User ID from session
    $total_payment = $_POST['total_payment'];  // Total payment due
    
    // Debugging: Output the received values
    error_log("User ID: $user_id, Payment Amount: $payment_amount, Total Payment: $total_payment");

    // Validate payment amount
    if ($payment_amount <= 0 || $payment_amount > $total_payment) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid payment amount.'
        ]);
        exit;
    }

    // Start a transaction to ensure data consistency
    mysqli_begin_transaction($conn);

    try {
        // Insert the payment into the payments table
        $sql = "INSERT INTO payments (user_id, amount, payment_date) VALUES ('$user_id', '$payment_amount', NOW())";
        if (!mysqli_query($conn, $sql)) {
            throw new Exception("Error inserting payment: " . mysqli_error($conn));
        }

        // Update the user's balance
        $sql_balance = "UPDATE users SET balance = balance - $payment_amount WHERE id = '$user_id'";  // Correct the column name if necessary
        if (!mysqli_query($conn, $sql_balance)) {
            throw new Exception("Error updating balance: " . mysqli_error($conn));
        }

        // Commit the transaction
        if (!mysqli_commit($conn)) {
            throw new Exception("Error committing the transaction: " . mysqli_error($conn));
        }

        // Get the new balance after the payment
        $new_balance_sql = "SELECT balance FROM users WHERE id = '$user_id'";
        $result = mysqli_query($conn, $new_balance_sql);
        $new_balance = mysqli_fetch_assoc($result)['balance'];

        // Return the response with the updated balance
        echo json_encode([
            'status' => 'success',
            'new_balance' => number_format($new_balance, 2)  // Format the new balance
        ]);

    } catch (Exception $e) {
        // Rollback if there is any error
        mysqli_rollback($conn);
        echo json_encode([
            'status' => 'error',
            'message' => 'Payment failed: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request. Missing parameters.'
    ]);
}
?>
